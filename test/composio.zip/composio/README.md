# Composio Auth App

### 🏃 Run locally
```bash
uvicorn backend.main:app --reload
npx live-server frontend
