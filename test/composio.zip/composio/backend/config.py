API_KEY = "ak_GepAqzYQ6d6WggBF_zot"
BASE_URL = "https://backend.composio.dev/api/v3"

HEADERS = {
    "x-api-key": API_KEY,
    "Content-Type": "application/json"
}
