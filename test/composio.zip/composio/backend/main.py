from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.routes import auth_configs, connectors

app = FastAPI(title="Auth Config Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
)

app.include_router(auth_configs.router, prefix="/auth")
app.include_router(connectors.router, prefix="/connectors")

@app.get("/")
def root():
    return {"message": "Backend running ✅"}
